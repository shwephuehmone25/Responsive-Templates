$('.menu-trigger').on('click', function () {
    var rightVal = 0;
    if ($(this).hasClass('menu')) {
        rightVal = -300;
        $(this).removeClass('menu');
    } else {
        $(this).addClass('menu');
    }
});

$(".menu-trigger").click(function () {
    let nav = $(".nav");
    nav.toggleClass("show-nav");
});

$('.nav-li a').click(function () {
    $('.nav-li a').removeClass("active");
    $(this).addClass("active");
});


$(".mission-div > div").heightLine();
$(".footer-inner > div").heightLine();
$(".strategic > div").heightLine();
$(".ul-div > ul").heightLine();
$(".stra-form > div").heightLine();

$(".link").click(function () {
    $(".link").toggleClass("available");
})

$(".product-link").click(function () {
    $(".product-link").removeClass("available");
    $(this).addClass("available");
    $("#tab").hide();

    var activeTab = $(this).find("a").attr('href');
    $(activeTab).fadeIn();
    return false;
});
$(function () {
    $(".minus").addClass("open");
    $(".plus,.minus").click(function () {
        $(".open").not(this).removeClass("open").next().slideUp(300);
        $(this).toggleClass("open").next().slideToggle(300);
    });

})
$(document).ready(function () {
    if (window.matchMedia('(max-width: 640px)').matches) {
        $(".strategic > div").heightLine("destroy");
    }
});